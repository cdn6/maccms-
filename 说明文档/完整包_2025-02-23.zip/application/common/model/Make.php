<?php
namespace app\common\model;

class Make extends Base {


}