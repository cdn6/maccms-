## 创建 database.php 文件可触发自动升级脚本

- sql语句如下
```php
<?php 
/*creates*/
if(empty($col_list[$pre.'annex'])){
    $sql .= " ;";
    $sql .="\r";
}
if(empty($col_list[$pre.'website'])){
    $sql .= ""
}
```