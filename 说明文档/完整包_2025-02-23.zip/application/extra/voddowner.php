<?php
return array (
  'http' => 
  array (
    'status' => '1',
    'from' => 'http',
    'show' => 'http下载',
    'des' => 'des提示信息',
    'ps' => '0',
    'parse' => '',
    'sort' => '90',
    'tip' => 'tip提示信息',
    'id' => 'http',
  ),
  'xunlei' => 
  array (
    'status' => '1',
    'from' => 'xunlei',
    'show' => 'xunlei下载',
    'des' => 'des提示信息',
    'target' => '_self',
    'ps' => '0',
    'parse' => '',
    'sort' => '90',
    'tip' => 'tip提示信息',
    'id' => 'xunlei',
  ),
);